Ezequiel 13-15

Então a palavra do Senhor veio a mim, dizendo: Filho do homem, profetiza contra os profetas de Israel que profetizam, e dize aos que só profetizam de seu próprio coração: Ouvi a palavra do Senhor. (Ezequiel 13:1-2)

Deus confronta os profetas que falam do próprio coração, não da boca de Deus. Eles dizem o que o povo quer ouvir, não o que Deus precisa dizer. O problema não é falta de voz; é falta de autoridade.

Quando você profetiza por conta própria, você consola no lugar de confrontar, promete o que Deus não prometeu e constrói muros de papel que caem na primeira ventania. A palavra que vem do coração humano parece bonita, mas não tem fundamento.

Deus não precisa de coadjuvantes. Ele busca portadores da verdade. O profeta não é um animador de plateia; é um porta-voz do Altíssimo. Se o silêncio de Deus constrange, melhor ficar quieto do que encher o espaço com o que veio da sua mente.

A unção não se ganha com volume, se ganha com obediência.
