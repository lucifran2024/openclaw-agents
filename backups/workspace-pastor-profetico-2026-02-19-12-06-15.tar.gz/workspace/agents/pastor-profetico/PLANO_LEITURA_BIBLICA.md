# PLANO DE LEITURA BÍBLICA - LUCIFRAN

Este arquivo contém o plano de leitura bíblica oficial, com datas e as passagens correspondentes.

---

# SSOT — PLANO DE LEITURA BÍBLICA

### INDEX_DIAS_BEGIN
2025-10-12 | Neemias 10-13
2025-10-13 | Ester 1-3
2025-10-14 | Ester 4-7
2025-10-15 | Ester 8-10
2025-10-16 | Jó 1-3
2025-10-17 | Jó 4-6
2025-10-18 | Jó 7-9
2025-10-19 | Jó 10-12
2025-10-20 | Jó 13-15
2025-10-21 | Jó 16-18
2025-10-22 | Jó 19-21
2025-10-23 | Jó 22-24
2025-10-24 | Jó 25-27
2025-10-25 | Jó 28-30
2025-10-26 | Jó 31-33
2025-10-27 | Jó 34-36
2025-10-28 | Jó 37-39
2025-10-29 | Jó 40-42
2025-10-30 | Salmos 1-3
2025-10-31 | Salmos 4-6
2025-11-01 | Salmos 7-9
2025-11-02 | Salmos 10-12
2025-11-03 | Salmos 13-15
2025-11-04 | Salmos 16-18
2025-11-05 | Salmos 19-21
2025-11-06 | Salmos 22-24
2025-11-07 | Salmos 25-27
2025-11-08 | Salmos 28-30
2025-11-09 | Salmos 31-33
2025-11-10 | Salmos 34-36
2025-11-11 | Salmos 37-39
2025-11-12 | Salmos 40-42
2025-11-13 | Salmos 43-45
2025-11-14 | Salmos 46-48
2025-11-15 | Salmos 49-51
2025-11-16 | Salmos 52-54
2025-11-17 | Salmos 55-57
2025-11-18 | Salmos 58-60
2025-11-19 | Salmos 61-63
2025-11-20 | Salmos 64-66
2025-11-21 | Salmos 67-69
2025-11-22 | Salmos 70-72
2025-11-23 | Salmos 73-75
2025-11-24 | Salmos 76-78
2025-11-25 | Salmos 79-81
2025-11-26 | Salmos 82-84
2025-11-27 | Salmos 85-87
2025-11-28 | Salmos 88-90
2025-11-29 | Salmos 91-93
2025-11-30 | Salmos 94-96
2025-12-01 | Salmos 97-99
2025-12-02 | Salmos 100-102
2025-12-03 | Salmos 103-105
2025-12-04 | Salmos 106-108
2025-12-05 | Salmos 109-111
2025-12-06 | Salmos 112-114
2025-12-07 | Salmos 115-117
2025-12-08 | Salmos 118-120
2025-12-09 | Salmos 121-123
2025-12-10 | Salmos 124-126
2025-12-11 | Salmos 127-129
2025-12-12 | Salmos 130-132
2025-12-13 | Salmos 133-135
2025-12-14 | Salmos 136-138
2025-12-15 | Salmos 139-141
2025-12-16 | Salmos 142-144
2025-12-17 | Salmos 145-147
2025-12-18 | Salmos 148-150
2025-12-19 | Provérbios 1-3
2025-12-20 | Provérbios 4-6
2025-12-21 | Provérbios 7-9
2025-12-22 | Provérbios 10-12
2025-12-23 | Provérbios 13-15
2025-12-24 | Provérbios 16-18
2025-12-25 | Provérbios 19-21
2025-12-26 | Provérbios 22-24
2025-12-27 | Provérbios 25-27
2025-12-28 | Provérbios 28-30
2025-12-29 | Provérbios 31; Eclesiastes 1-3
2025-12-30 | Eclesiastes 4-6
2025-12-31 | Eclesiastes 7-9
2026-01-01 | Eclesiastes 10-12
2026-01-02 | Cantares 1-4
2026-01-03 | Cantares 5-8
2026-01-04 | Isaías 1-3
2026-01-05 | Isaías 4-6
2026-01-06 | Isaías 7-9
2026-01-07 | Isaías 10-12
2026-01-08 | Isaías 13-15
2026-01-09 | Isaías 16-18
2026-01-10 | Isaías 19-21
2026-01-11 | Isaías 22-24
2026-01-12 | Isaías 25-27
2026-01-13 | Isaías 28-30
2026-01-14 | Isaías 31-33
2026-01-15 | Isaías 34-36
2026-01-16 | Isaías 37-39
2026-01-17 | Isaías 40-42
2026-01-18 | Isaías 43-45
2026-01-19 | Isaías 46-48
2026-01-20 | Isaías 49-51
2026-01-21 | Isaías 52-54
2026-01-22 | Isaías 55-57
2026-01-23 | Isaías 58-60
2026-01-24 | Isaías 61-63
2026-01-25 | Isaías 64-66
2026-01-26 | Jeremias 1-3
2026-01-27 | Jeremias 4-6
2026-01-28 | Jeremias 7-9
2026-01-29 | Jeremias 10-12
2026-01-30 | Jeremias 13-15
2026-01-31 | Jeremias 16-18
2026-02-01 | Jeremias 19-21
2026-02-02 | Jeremias 22-24
2026-02-03 | Jeremias 25-27
2026-02-04 | Jeremias 28-30
2026-02-05 | Jeremias 31-33
2026-02-06 | Jeremias 34-36
2026-02-07 | Jeremias 37-39
2026-02-08 | Jeremias 40-42
2026-02-09 | Jeremias 43-45
2026-02-10 | Jeremias 46-48
2026-02-11 | Jeremias 49-50
2026-02-12 | Jeremias 51-52; Lamentações 1
2026-02-13 | Lamentações 2-4
2026-02-14 | Lamentações 5; Ezequiel 1-3
2026-02-15 | Ezequiel 4-6
2026-02-16 | Ezequiel 7-9
2026-02-17 | Ezequiel 10-12
2026-02-18 | Ezequiel 13-15
2026-02-19 | Ezequiel 16-18
2026-02-20 | Ezequiel 19-21
2026-02-21 | Ezequiel 22-24
2026-02-22 | Ezequiel 25-27
2026-02-23 | Ezequiel 28-30
2026-02-24 | Ezequiel 31-33
2026-02-25 | Ezequiel 34-36
2026-02-26 | Ezequiel 37-39
2026-02-27 | Ezequiel 40-42
2026-02-28 | Ezequiel 43-45
2026-03-01 | Ezequiel 46-48
2026-03-02 | Oséias 1-3
2026-03-03 | Oséias 4-6
2026-03-04 | Oséias 7-9
2026-03-05 | Oséias 10-12
2026-03-06 | Oséias 13-14; Joel 1
2026-03-07 | Joel 2-3; Amós 1-3
2026-03-08 | Amós 4-6
2026-03-09 | Amós 7-9; Obadias 1
2026-03-10 | Jonas 1-4
2026-03-11 | Miqueias 1-3
2026-03-12 | Miqueias 4-5; Naum 1-3
2026-03-13 | Habacuque 1-3
2026-03-14 | Sofonias 1-3
2026-03-15 | Ageu 1-2
2026-03-16 | Zacarias 1-3
2026-03-17 | Zacarias 4-6
2026-03-18 | Zacarias 7-9
2026-03-19 | Zacarias 10-12
2026-03-20 | Zacarias 13-14; Malaquias 1-2
2026-03-21 | Malaquias 3-4; Mateus 1-2
2026-03-22 | Mateus 3-4
2026-03-23 | Mateus 5-7
2026-03-24 | Mateus 8-10
2026-03-25 | Mateus 11-13
2026-03-26 | Mateus 14-16
2026-03-27 | Mateus 17-19
2026-03-28 | Mateus 20-22
2026-03-29 | Mateus 23-25
2026-03-30 | Mateus 26-28
2026-03-31 | Marcos 1-3
2026-04-01 | Marcos 4-6
2026-04-02 | Marcos 7-9
2026-04-03 | Marcos 10-12
2026-04-04 | Marcos 13-16
2026-04-05 | Lucas 1-2
2026-04-06 | Lucas 3-4
2026-04-07 | Lucas 5-7
2026-04-08 | Lucas 8-10
2026-04-09 | Lucas 11-13
2026-04-10 | Lucas 14-16
2026-04-11 | Lucas 17-19
2026-04-12 | Lucas 20-22
2026-04-13 | Lucas 23-24
2026-04-14 | João 1-3
2026-04-15 | João 4-6
2026-04-16 | João 7-9
2026-04-17 | João 10-12
2026-04-18 | João 13-15
2026-04-19 | João 16-18
2026-04-20 | João 19-21
2026-04-21 | Atos 1-3
2026-04-22 | Atos 4-6
2026-04-23 | Atos 7-9
2026-04-24 | Atos 10-12
2026-04-25 | Atos 13-15
2026-04-26 | Atos 16-18
2026-04-27 | Atos 19-21
2026-04-28 | Atos 22-24
2026-04-29 | Atos 25-27
2026-04-30 | Atos 28; Romanos 1
2026-05-01 | Romanos 2-4
2026-05-02 | Romanos 5-7
2026-05-03 | Romanos 8-10
2026-05-04 | Romanos 11-13
2026-05-05 | Romanos 14-16
2026-05-06 | 1 Coríntios 1-3
2026-05-07 | 1 Coríntios 4-6
2026-05-08 | 1 Coríntios 7-9
2026-05-09 | 1 Coríntios 10-12
2026-05-10 | 1 Coríntios 13-15
2026-05-11 | 1 Coríntios 16; 2 Coríntios 1-2
2026-05-12 | 2 Coríntios 3-5
2026-05-13 | 2 Coríntios 6-8
2026-05-14 | 2 Coríntios 9-11
2026-05-15 | 2 Coríntios 12-13; Gálatas 1
2026-05-16 | Gálatas 2-4
2026-05-17 | Gálatas 5-6; Efésios 1
2026-05-18 | Efésios 2-4
2026-05-19 | Efésios 5-6; Filipenses 1
2026-05-20 | Filipenses 2-4
2026-05-21 | Colossenses 1-2
2026-05-22 | Colossenses 3-4; 1 Tessalonicenses 1
2026-05-23 | 1 Tessalonicenses 2-5
2026-05-24 | 2 Tessalonicenses 1-3
2026-05-25 | 1 Timóteo 1-3

---

## INSTRUÇÕES

Este é o plano oficial de leitura bíblica. A Pastora Chefe consultará este arquivo para selecionar a passagem do dia correspondente.

---

*Última atualização: 18/02/2026 - Plano oficial do Lucifran*
